BAI TAP CSS WEEK 1 - HW1

Trong thu muc nay co:
- index.html
- neighborhood.html
- parks.html
- css/style.css

Luu y:
Cac trang HTML goc su dung anh trong thu muc images/.
De website hien thi day du anh, hay sao chep nguyen thu muc images/ tu repository goc
vao cung cap voi index.html, neighborhood.html va parks.html.

Cau truc can co:
CSS-week1-HW1/
  index.html
  neighborhood.html
  parks.html
  images/
  css/
    style.css

Ca ba trang da duoc lien ket den cung mot file css/style.css.
